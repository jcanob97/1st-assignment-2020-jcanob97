package ArnauMerino_JanCano;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import cat.tecnocampus.mobileapps.practica1.Practica1_ArnauMerino_JanCano.R;

public class EditStudent extends AppCompatActivity {

    private int index;

    private EditText nom;
    private EditText cognom;
    private EditText telefon;
    private EditText dni;
    private EditText grau;
    private EditText curs;

    private Button botoEliminar;
    private Button botoconfirmar;
    private Button botocancelar;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_student);

        Intent intent = getIntent();

        initVariables(intent);

        botoEliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent result = new Intent();
                result.putExtra("index", index);
                setResult(3, result);
                finish();
            }
        });

        botoconfirmar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(canSend()) {
                    Intent result = new Intent();
                    result.putExtra("index", index);
                    result.putExtra("nom", nom.getText().toString());
                    result.putExtra("cognom", cognom.getText().toString());
                    result.putExtra("telefon", telefon.getText().toString());
                    result.putExtra("dni", dni.getText().toString());
                    result.putExtra("grau", grau.getText().toString());
                    result.putExtra("curs", curs.getText().toString());
                    setResult(RESULT_OK, result);
                    finish();
                }
            }
        });

        botocancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent result = new Intent();
                setResult(RESULT_CANCELED, result);
                finish();
            }
        });
    }

    private void initVariables(Intent intent){
        nom = findViewById(R.id.nomEstudiantEditar);
        cognom = findViewById(R.id.lCognomEstudiantEditat);
        telefon = findViewById(R.id.telefonEstudantEditar);
        dni = findViewById(R.id.dniEstudiantEditar);
        grau = findViewById(R.id.grauEstudiantEditar);
        curs = findViewById(R.id.cursEstudaintEditar);
        botoEliminar = findViewById(R.id.eliminarusuari);
        botoconfirmar = findViewById(R.id.confirmacio);
        botocancelar = findViewById(R.id.cancelacio);

        index = Integer.parseInt(intent.getStringExtra("index"));

        nom.setText(intent.getStringExtra("nom"));
        cognom.setText(intent.getStringExtra("cognom"));
        telefon.setText(intent.getStringExtra("telefon"));
        dni.setText(intent.getStringExtra("dni"));
        grau.setText(intent.getStringExtra("grau"));
        curs.setText(intent.getStringExtra("curs"));

    }

    private boolean canSend() {
        if (nom.getText().toString().equals(""))
            return false;
        if (telefon.getText().toString().equals(""))
            return false;
        if (grau.getText().toString().equals(""))
            return false;
        if (curs.getText().toString().equals(""))
            return false;
        if (dni.getText().toString().equals(""))
            return false;
        if (cognom.getText().toString().equals(""))
            return false;


        return true;
    }

}
