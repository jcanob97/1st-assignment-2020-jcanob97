package ArnauMerino_JanCano;

public class Estudiant {

    private String nom;
    private String cognom;
    private String grau;
    private int telefon;
    private String DNI;
    private int curs;

    public Estudiant(String nom, String cognom, String grau, int telefon, String DNI, int curs) {
        this.nom = nom;
        this.cognom = cognom;
        this.grau = grau;
        this.telefon = telefon;
        this.DNI = DNI;
        this.curs = curs;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getCognom() {
        return cognom;
    }

    public void setCognom(String cognom) {
        this.cognom = cognom;
    }

    public String getGrau() {
        return grau;
    }

    public void setGrau(String grau) {
        this.grau = grau;
    }

    public int getTelefon() {
        return telefon;
    }

    public void setTelefon(int telefon) {
        this.telefon = telefon;
    }

    public String getDNI() {
        return DNI;
    }

    public void setDNI(String DNI) {
        this.DNI = DNI;
    }

    public int getCurs() {
        return curs;
    }

    public void setCurs(int curs) {
        this.curs = curs;
    }

}
