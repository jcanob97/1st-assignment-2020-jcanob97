package ArnauMerino_JanCano;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import cat.tecnocampus.mobileapps.practica1.Practica1_ArnauMerino_JanCano.R;

public class CreateStudent extends AppCompatActivity {

    private EditText nom;
    private EditText cognom;
    private EditText telefon;
    private EditText dni;
    private EditText grau;
    private EditText curs;

    private Button crearboto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_student);

        nom = findViewById(R.id.NomNouEstudiant);
        cognom = findViewById(R.id.cognomText2);
        telefon = findViewById(R.id.telefonNouEstudiant);
        dni = findViewById(R.id.dniNewStudent);
        grau = findViewById(R.id.grauNewStudent);
        curs = findViewById(R.id.cursNouEstudiant);

        crearboto = findViewById(R.id.CrearBoto);

        crearboto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(comprovant()){
                    Intent resultat = new Intent();
                    resultat.putExtra("nom", nom.getText().toString());
                    resultat.putExtra("Cognom", cognom.getText().toString());
                    resultat.putExtra("telefon", telefon.getText().toString());
                    resultat.putExtra("dni", dni.getText().toString());
                    resultat.putExtra("grau", grau.getText().toString());
                    resultat.putExtra("curs", curs.getText().toString());
                    setResult(RESULT_OK, resultat);
                    finish();
                }
            }
        });
    }

    private boolean comprovant() {
        if (nom.getText().toString().equals(""))
            return false;
        if (telefon.getText().toString().equals(""))
            return false;
        if (grau.getText().toString().equals(""))
            return false;
        if (curs.getText().toString().equals(""))
            return false;
        if (dni.getText().toString().equals(""))
            return false;
        if (cognom.getText().toString().equals(""))
            return false;


        return true;
    }
}
