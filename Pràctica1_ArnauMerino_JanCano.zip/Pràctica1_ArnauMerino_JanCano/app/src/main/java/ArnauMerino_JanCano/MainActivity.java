package ArnauMerino_JanCano;

import android.content.Intent;
import android.content.res.Configuration;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;

import cat.tecnocampus.mobileapps.practica1.Practica1_ArnauMerino_JanCano.R;


public class MainActivity extends AppCompatActivity {

    private static final int getestudiant = 1;
    private static final int editarestudiant = 2;

    private Adapter Adapter;
    private RecyclerView llistaestudaints;
    private Button afegirboto;
    private ArrayList<Estudiant> dades;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        llistaestudaints = findViewById(R.id.student_list);
        afegirboto = findViewById(R.id.button_afegir_estudiant);

        EstudiantsInicials();
        RecyclerView.LayoutManager mLayoutManager = null;

        if(getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
            mLayoutManager = new LinearLayoutManager(this);
        } else {
            mLayoutManager = new GridLayoutManager(this, 2);
        }

        llistaestudaints.setLayoutManager(mLayoutManager);

        Adapter = new Adapter(dades);

        Adapter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try {

                    int index = llistaestudaints.getChildAdapterPosition(v);

                    Estudiant editEstudiant = dades.get(index);

                    Intent intent = new Intent(MainActivity.this, EditStudent.class);
                    intent.putExtra("index", "" + index);
                    intent.putExtra("nom", editEstudiant.getNom());
                    intent.putExtra("cognom", editEstudiant.getCognom());
                    intent.putExtra("grau", editEstudiant.getGrau());
                    intent.putExtra("dni", editEstudiant.getDNI());
                    intent.putExtra("telefon", "" + editEstudiant.getTelefon());
                    intent.putExtra("curs", "" + editEstudiant.getCurs());

                    startActivityForResult(intent, editarestudiant);

                } catch (Exception e) {
                    Log.d("VCA", e.getMessage());
                }
            }
        });

        llistaestudaints.setAdapter(Adapter);

        afegirboto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, CreateStudent.class);
                startActivityForResult(intent, getestudiant);

            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // Check which request we're responding to
        if (requestCode == getestudiant) {
            // Make sure the request was successful
            if (resultCode == RESULT_OK) {

                Estudiant estudiant = new Estudiant(
                        data.getStringExtra("name"),
                        data.getStringExtra("lastName"),
                        data.getStringExtra("grau"),
                        Integer.parseInt(data.getStringExtra("telefon")),
                        data.getStringExtra("dni"),
                        Integer.parseInt(data.getStringExtra("curs"))
                );

                this.dades.add(estudiant);
                Adapter.notifyDataSetChanged(); // Refresh data
            }
        } else {
            if (requestCode == editarestudiant) {

                int index = -1;

                try {
                    index = data.getIntExtra("index", -1);
                } catch(Exception e){
                    Log.d("VCA", e.getMessage());
                }

                if (resultCode == RESULT_OK && index != -1) {
                    Estudiant estudiant = this.dades.get(index);

                    estudiant.setNom(data.getStringExtra("name"));
                    estudiant.setCognom(data.getStringExtra("lastName"));
                    estudiant.setGrau(data.getStringExtra("grau"));
                    estudiant.setDNI(data.getStringExtra("dni"));
                    estudiant.setTelefon(Integer.parseInt(data.getStringExtra("telefon")));
                    estudiant.setCurs(Integer.parseInt(data.getStringExtra("curs")));
                } else {
                    if (resultCode == 3 && index != -1) {
                        this.dades.remove(index);
                    }
                }

                Adapter.notifyDataSetChanged(); // Refresh data

            }
        }
    }

    private void EstudiantsInicials(){
        dades = new ArrayList<>();
        dades.add(new Estudiant("Arnau", "Merino Vintro", "Enginyeria Informatica", 66655544, "123456789", 3));
        dades.add(new Estudiant("Jan", "Cano Barbero", "Enginyeria Informatica", 666554433, "123456789", 3));
    }
}
