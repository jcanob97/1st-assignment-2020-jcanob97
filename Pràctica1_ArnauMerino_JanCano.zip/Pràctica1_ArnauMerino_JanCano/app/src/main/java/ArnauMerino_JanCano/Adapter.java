package ArnauMerino_JanCano;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

import cat.tecnocampus.mobileapps.practica1.Practica1_ArnauMerino_JanCano.R;

public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> implements View.OnClickListener {
    private ArrayList<Estudiant> data;
    private View.OnClickListener listener;

    public Adapter(ArrayList<Estudiant> data) {
        this.data = data;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.student_item, viewGroup, false);
        ViewHolder vh = new ViewHolder(v);

        v.setOnClickListener(this);

        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        Estudiant estudiant = data.get(i);
        viewHolder.Nom.setText(estudiant.getNom());
        viewHolder.Cognom.setText(estudiant.getCognom());
        viewHolder.Grau.setText(estudiant.getGrau());
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public void setOnClickListener(View.OnClickListener listener){
        this.listener = listener;
    }

    @Override
    public void onClick(View v) {
        if(listener!=null){
            listener.onClick(v);
        }
    }


    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView Nom;
        public TextView Cognom;
        public TextView Grau;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            Nom = itemView.findViewById(R.id.student_name);
            Cognom = itemView.findViewById(R.id.student_surname);
            Grau =  itemView.findViewById(R.id.student_degree);
        }
    }
}
